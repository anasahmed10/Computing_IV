/**********************************************************************
 *                                                  
 *  Guitar Hero: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Anas Ahmed

Hours to complete assignment : 20 Hours

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes


/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  As a pair, or individually?
 **********************************************************************/
No

/**********************************************************************
 *  Did you implement exseptions to check your StringSound 
 *	implementation?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
Yes, I throw an exception in my enqueue and dequeue functions if the queue is full or empty respectively.

/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/
N/A


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I ended up rewriting my entire code as I was constantly hitting a segmentation fault in my previous code.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/