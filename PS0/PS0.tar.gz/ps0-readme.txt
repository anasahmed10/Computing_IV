/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Anas Ahmed

Operating system you're using (Linux, OS X, or Windows): Ubuntu VM

IDE or text editor you're using: Emacs

Hours to complete assignment: 2.5 hours

/**********************************************************************
 *  List some information (optionally) to help me get to know you.
 **********************************************************************/

Did you take Computing I at UML?

Yes, with Sarita Hakimian

/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/
b applies to this point the most as the internet offers a wide range of resources that desperate students can resort to. Websites such as Chegg, qualify as unauthorized materials that a student who may be left with no other options may resort to. It is important to only use resources like Stack Overflow to help further your knowledge rather than copy a solution from another site.


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I had to use a jpg file for my sprite instead of a png file because I could not convert the sprite to png


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

